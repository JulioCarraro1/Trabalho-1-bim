package com.example.trabalho1bim;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText nome, email, idade, disciplina, nota1, nota2;
    private TextView erro, resultado;
    private Button enviar, limpar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        nome = findViewById(R.id.nome);
        email = findViewById(R.id.email);
        idade = findViewById(R.id.idade);
        disciplina = findViewById(R.id.disciplina);
        nota1 = findViewById(R.id.nota1);
        nota2 = findViewById(R.id.nota2);
        enviar = findViewById(R.id.enviar);
        limpar = findViewById(R.id.limpar);
        erro = findViewById(R.id.erro);
        resultado = findViewById(R.id.resultado);


        enviar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validarFormulario();
            }
        });


        limpar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                limparFormulario();
            }
        });
    }


    private void validarFormulario() {
        String nomeStr = nome.getText().toString();
        String emailStr = email.getText().toString();
        String idadeStr = idade.getText().toString();
        String disciplinaStr = disciplina.getText().toString();
        String nota1Str = nota1.getText().toString();
        String nota2Str = nota2.getText().toString();

        StringBuilder erros = new StringBuilder();


        if (TextUtils.isEmpty(nomeStr)) {
            erros.append("O campo de nome está vazio.\n");
        }
        if (TextUtils.isEmpty(emailStr) || !Patterns.EMAIL_ADDRESS.matcher(emailStr).matches()) {
            erros.append("O email é inválido.\n");
        }
        if (TextUtils.isEmpty(idadeStr) || !isNumeroValido(idadeStr)) {
            erros.append("A idade deve ser um número positivo.\n");
        }
        if (TextUtils.isEmpty(disciplinaStr)) {
            erros.append("O campo de disciplina está vazio.\n");
        }
        if (TextUtils.isEmpty(nota1Str) || !isNotaValida(nota1Str)) {
            erros.append("A Nota 1 deve ser um valor entre 0 e 10.\n");
        }
        if (TextUtils.isEmpty(nota2Str) || !isNotaValida(nota2Str)) {
            erros.append("A Nota 2 deve ser um valor entre 0 e 10.\n");
        }


        if (erros.length() > 0) {
            erro.setText(erros.toString());
            erro.setVisibility(View.VISIBLE);
            resultado.setVisibility(View.GONE);
        } else {
            float nota1Float = Float.parseFloat(nota1Str);
            float nota2Float = Float.parseFloat(nota2Str);
            float media = (nota1Float + nota2Float) / 2;
            String status = media >= 6 ? "Aprovado" : "Reprovado";

            String resumo = "Nome: " + nomeStr + "\n"
                    + "Email: " + emailStr + "\n"
                    + "Idade: " + idadeStr + "\n"
                    + "Disciplina: " + disciplinaStr + "\n"
                    + "Notas: " + nota1Float + " e " + nota2Float + "\n"
                    + "Média: " + media + "\n"
                    + "Status: " + status;

            resultado.setText(resumo);
            resultado.setVisibility(View.VISIBLE);
            erro.setVisibility(View.GONE);
        }
    }


    private boolean isNumeroValido(String numeroStr) {
        try {
            int numero = Integer.parseInt(numeroStr);
            return numero > 0;
        } catch (NumberFormatException e) {
            return false;
        }
    }


    private boolean isNotaValida(String notaStr) {
        try {
            float nota = Float.parseFloat(notaStr);
            return nota >= 0 && nota <= 10;
        } catch (NumberFormatException e) {
            return false;
        }
    }


    private void limparFormulario() {
        nome.setText("");
        email.setText("");
        idade.setText("");
        disciplina.setText("");
        nota1.setText("");
        nota2.setText("");
        erro.setVisibility(View.GONE);
        resultado.setVisibility(View.GONE);
    }
}
